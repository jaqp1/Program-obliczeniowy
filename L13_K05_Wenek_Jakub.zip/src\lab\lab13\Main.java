package lab.lab13;

public class Main {
    public static void main(String[] args) {
        new CMainForm("Lab 13").setVisible(true);
    }
}